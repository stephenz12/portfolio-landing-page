const hamburger = document.getElementById("hamburger");
const navMenu = document.getElementById("nav-menu");
const socialIcons = document.getElementById("social-icons");

hamburger.addEventListener("click", () => {
  navMenu.classList.toggle("active");
  socialIcons.classList.toggle("active");
});
